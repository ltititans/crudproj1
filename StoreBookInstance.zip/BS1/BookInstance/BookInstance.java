package com.lti.users;



public class BookInstance{
	protected int copy_instance;
	protected int store_id;
	protected int isbn;
	protected int order_detail_id;
	public BookInstance(int copy_instance,int store_id, int isbn, int order_detail_id) {
		super();
		this.copy_instance = copy_instance;
		this.store_id = store_id;
		this.isbn = isbn;
		this.order_detail_id = order_detail_id;
	}
	public BookInstance(int store_id, int isbn, int order_detail_id) {
		super();
		
		this.store_id = store_id;
		this.isbn = isbn;
		this.order_detail_id = order_detail_id;
	}
	public int getCopy_instance() {
		return copy_instance;
	}
	public void setCopy_instance(int copy_instance) {
		this.copy_instance = copy_instance;
	}
	public int getStore_id() {
		return store_id;
	}
	public void setStore_id(int store_id){
		this.store_id = store_id;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	@Override
	public String toString() {
		return "BookInstance [copy_instance=" + copy_instance + ", store_id=" + store_id + ", isbn=" + isbn + ",order_detail_id= "  +order_detail_id+ " ]";
	}
	
	
	
}