
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class BookInstanceDao {
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "123";

	private static final String INSERT_USERS_SQL = "INSERT INTO bookinstances VALUES "
			+ " (seq_bookinstances.NEXTVAL,?, ?, ?)";

	private static final String SELECT_USER_BY_ID = "select copy_instance,store_id,isbn,order_detail_id  from bookinstances where copy_instance =?";
	private static final String SELECT_ALL_USERS = "select * from bookinstances";
	private static final String DELETE_USERS_SQL = "delete from bookinstances where copy_instance = ?";
	private static final String UPDATE_USERS_SQL = "update bookinstances set store_id = ?,"
			+ "isbn= ?," + "order_detail_id=? where copy_instance = ?";

	public BookInstanceDao() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertUser(BookInstance bookinstance) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_USERS_SQL);
			preparedStatement.setInt(1, bookinstance.getStore_id());
			preparedStatement.setInt(2, bookinstance.getIsbn());
			preparedStatement.setInt(3, bookinstance.getOrder_detail_id());
			
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public BookInstance selectUser(int copy_instance) {
		BookInstance bookinstance = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_USER_BY_ID);
			preparedStatement.setInt(1, copy_instance);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int store_id = rs.getInt("store_id");
				int isbn= rs.getInt("isbn");
				int order_detail_id = rs.getInt("order_detail_id");
				
				
				bookinstance = new BookInstance(copy_instance, store_id, isbn,order_detail_id);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return bookinstance;
	}

	public List<BookInstance> selectAllUsers() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<BookInstance> bookinstances = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_USERS);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int copy_instance = rs.getInt("copy_instance");
				int store_id = rs.getInt("store_id");
				int isbn= rs.getInt("isbn");
				int order_detail_id = rs.getInt("order_detail_id");
			
				bookinstances.add(new BookInstance(copy_instance, store_id, isbn,order_detail_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return bookinstances;
	}

	public boolean deleteUser(int copy_instance) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_USERS_SQL);) {
			statement.setInt(1, copy_instance);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(BookInstance bookinstance) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_USERS_SQL);) {
			Statement.setInt(1, bookinstance.getStore_id());
			Statement.setInt(2, bookinstance.getIsbn());
			Statement.setInt(3, bookinstance.getOrder_detail_id());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		
				ex.printStackTrace();
				
				}
			
}
