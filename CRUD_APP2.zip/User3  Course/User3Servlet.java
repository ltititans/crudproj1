public class User3Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private User3Dao user3DAO;
	
	public void init() {
		user3DAO= new User3Dao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertUser(request, response);
				break;
			case "/delete":
				deleteUser(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateUser(request, response);
				break;
			default:
				listUser(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<User3> listUser = user3DAO.selectAllUsers();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user3-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user3-form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("courseno"));
		User3 existingUser = user3DAO.selectUser(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user3-form.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		String cname = request.getParameter("cname");
		String duration = request.getParameter("duration");
		String prerequisite = request.getParameter("prerequisite");
		int iid = Integer.parseInt(request.getParameter("iid"));
		User3 newUser = new User3(cname, duration, prerequisite, iid);
		user3DAO.insertUser(newUser);
		response.sendRedirect("list");
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int courseno = Integer.parseInt(request.getParameter("courseno"));
		String cname = request.getParameter("cname");
		String duration = request.getParameter("duration");
		int iid = Integer.parseInt(request.getParameter("iid"));

		User3 book = new User3(courseno, cname, duration, iid);
		user3DAO.updateUser(book);
		response.sendRedirect("list");
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int courseno = Integer.parseInt(request.getParameter("courseno"));
		user3DAO.deleteUser(courseno);
		response.sendRedirect("list");

	}

}
