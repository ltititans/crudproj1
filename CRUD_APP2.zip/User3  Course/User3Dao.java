public class User3Dao {
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "123";

	private static final String INSERT_USERS_SQL = "INSERT INTO users3 VALUES "
			+ " (seq_users3.NEXTVAL,?, ?)";

	private static final String SELECT_USER_BY_ID = "select courseno,cname,duration,prerequisite,iid from users3 where courseno =?";
	private static final String SELECT_ALL_USERS = "select * from courseno";
	private static final String DELETE_USERS_SQL = "delete from users3 where courseno = ?";
	private static final String UPDATE_USERS_SQL = "update users3 set cname = ?,"
			+ "duration= ?," + "prerequisite= ?," + "iid= ? where courseno = ?";

	public User3Dao() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertUser(User3 user3) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_USERS_SQL);
			preparedStatement.setString(1, user3.getCname());
			preparedStatement.setString(2, user3.getDuration());
			preparedStatement.setString(3, user3.getPrerequisite());
			preparedStatement.setString(4, user3.getIid());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public User3 selectUser(int courseno) {
		User3 user3 = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_USER_BY_ID);
			preparedStatement.setInt(1, courseno);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String cname = rs.getString("cname");
				String duration = rs.getString("duration");
				String prerequisite = rs.getString("prerequisite");
				int iid = rs.getInt("iid");

				user3 = new User3(courseno, cname, duration, prerequisite, iid);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user3;
	}

	public List<User3> selectAllUsers() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<User3> users3 = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_USERS);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int courseno = rs.getInt("courseno");
				String cname = rs.getString("cname");
				String duration= rs.getString("duration");
				String prerequisite = rs.getString("prerequisite");
				int iid = rs.getInt("iid");
				users3.add(new User3(courseno, cname, duration,prerequisite,iid));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users3;
	}

	public boolean deleteUser(int courseno) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_USERS_SQL);) {
			statement.setInt(1, courseno);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(User3 user3) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_USERS_SQL);) {
			statement.setString(1, user3.getCname());
			statement.setString(2, user3.getDuration());
			statement.setString(3, user3.getPrerequisite());
			statement.setInt(4, user3.getIid());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		
				ex.printStackTrace();
				
				}
			
}
