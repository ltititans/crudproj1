package com.lti.users;



public class User3 {
	private int courseno;
	private String cname;
	private String duration;
	private String prerequisite;
	private int iid;
	public User3(int courseno, String cname, String duration, String prerequisite, int iid) {
		this.courseno = courseno;
		this.cname = cname;
		this.duration = duration;
		this.prerequisite = prerequisite;
		this.iid= iid;
	}
	public User3(int courseno, String cname, String duration, String prerequisite, int iid) {
		
		this.cname = cname;
		this.duration = duration;
		this.prerequisite = prerequisite;
		this.iid= iid;
	}
	public int getCourseno() {
		return courseno;
	}
	public void setCourseno(int courseno) {
		this.courseno = courseno;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getPrerequisite() {
		return prerequisite;
	}
	public void setPrerequisite(String prerequisite) {
		this.prerequisite = prerequisite;
	}
	public int getIid() {
		return iid;
	}
	public void setIid iid) {
		this.iid = iid;
	}
	@Override
	public String toString() {
		return "CourseBean [courseno=" + courseno + ", cname=" + cname + ", duration=" + duration + ", prerequisite="
				+ prerequisite + ", iid=" + iid + "]";
	}
	

}
