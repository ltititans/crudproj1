package com.lti.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.DAO.User1Dao;
import com.lti.users.User1;



/**
 * Servlet implementation class User1Servlet
 */
@WebServlet("/")
public class User1Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
    private User1Dao user1DAO;
	
	public void init() {
		user1DAO= new User1Dao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertUser(request, response);
				break;
			case "/delete":
				deleteUser(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateUser(request, response);
				break;
			default:
				listUser(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<User1> listUser = user1DAO.selectAllUsers();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user1-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user1-form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("iid"));
		User1 existingUser = user1DAO.selectUser(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user1-form.jsp");
		request.setAttribute("user1", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		String iname = request.getParameter("iname");
		String room = request.getParameter("room");
		int dno=Integer.parseInt(request.getParameter("dno"));
		User1 newUser = new User1(iname, room, dno);
		user1DAO.insertUser(newUser);
		response.sendRedirect("list");
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int iid = Integer.parseInt(request.getParameter("iid"));
		String iname = request.getParameter("iname");
		String room = request.getParameter("room");
		int dno = Integer.parseInt(request.getParameter("dno"));

		User1 book = new User1(iid, iname, room, dno );
		user1DAO.updateUser(book);
		response.sendRedirect("list");
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int iid = Integer.parseInt(request.getParameter("iid"));
		user1DAO.deleteUser(iid);
		response.sendRedirect("list");

	}

}
