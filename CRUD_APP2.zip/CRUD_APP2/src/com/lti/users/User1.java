package com.lti.users;

public class User1 {
	private int iid;
	private String iname;
	private String room;
	private int dno;
	public User1(int iid, String iname, String room, int dno) {
		super();
		this.iid = iid;
		this.iname = iname;
		this.room = room;
		this.dno = dno;
	}
	public User1(String iname, String room, int dno) {
		super();
		this.iname = iname;
		this.room = room;
		this.dno = dno;
	}
	public int getIid() {
		return iid;
	}
	public void setIid(int iid) {
		this.iid = iid;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public int getDno() {
		return dno;
	}
	public void setDno(int dno) {
		this.dno = dno;
	}
	@Override
	public String toString() {
		return "User1 [iid=" + iid + ", iname=" + iname + ", room=" + room + ", dno=" + dno + "]";
	}
	
}
