package com.lti.users;

public class User2 {
	private int sno;
	private String sname;
	private String dob;
	
	private int courseno;
	private int iid;
	public User2(int sno, String sname, String dob, int courseno, int iid) {
		super();
		this.sno = sno;
		this.sname = sname;
		this.dob = dob;
		this.courseno = courseno;
		this.iid = iid;
	}
	
	public User2(String sname, String dob, int courseno, int iid) {
		super();
		this.sname = sname;
		this.dob = dob;
		this.courseno = courseno;
		this.iid = iid;
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public int getCourseno() {
		return courseno;
	}
	public void setCourseno(int courseno) {
		this.courseno = courseno;
	}
	public int getIid() {
		return iid;
	}
	public void setIid(int iid) {
		this.iid = iid;
	}
	
	@Override
	public String toString() {
		return "User2 [sno=" + sno + ", sname=" + sname + ", dob=" + dob + ", courseno=" + courseno + ", iid=" + iid
				+ "]";
	}
}
