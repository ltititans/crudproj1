package com.lti.users;



public class User {
	protected int dno;
	protected String dname;
	protected String location;
	public User(int dno, String dname, String location) {
		super();
		this.dno = dno;
		this.dname = dname;
		this.location = location;
	}
	public User(String dname, String location) {
		super();
		this.dname = dname;
		this.location = location;
	}
	public int getDno() {
		return dno;
	}
	public void setDno(int dno) {
		this.dno = dno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "User [dno=" + dno + ", dname=" + dname + ", location=" + location + "]";
	}
	
	
	
}