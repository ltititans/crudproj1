package com.lti.books;

public class BookInstance {
	   private int copy_instance;
	   private int store_id;
	   private int  isbn;
     private int order_details_id;
	public BookInstance(int copy_instance, int store_id, int isbn, int order_details_id) {
		super();
		this.isbn = isbn;
		this.copy_instance = copy_instance;
    this.store_id = store_id;
    this.order_details_id = order_details_id;
	}
	public BookInstance(int store_id, int isbn, int order_details_id) {
		super();
		this.isbn = isbn;
    this.store_id = store_id;
    this.order_details_id = order_details_id;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}

  public int getCopyInstance() {
    return copy_instance;
  }

  public void setCoptInstance(int copy_instance) {
    this.copy_instance = copy_instance
  }

  public int getStoreId() {
    return store_id;
  }

  public void setStoreId(int store_id) {
    this.store_id = store_id
  }

  public int getOrderDetailsId() {
    return order_details_id;
  }

  public void setOrderDetailsId(int order_details_id) {
    this.order_details_id = order_details_id;
  }

	@Override
	public String toString() {
		return "BookInstance [copy_instance = "+ copy_instance +", store_id = "+ store_id +", isbn=" + isbn + ", order_details_id = "+ order_details_id +"]";
	}
}