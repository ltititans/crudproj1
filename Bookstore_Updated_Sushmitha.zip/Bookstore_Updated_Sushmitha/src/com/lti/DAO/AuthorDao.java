package com.lti.DAO;




	import java.sql.Connection;

	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.ArrayList;
	import java.util.List;

import com.lti.books.Author;


	public class AuthorDao {
		private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
		private String jdbcUsername = "system";
		private String jdbcPassword = "123";

		private static final String INSERT_USERS_SQL = "INSERT INTO author1 VALUES "
				+ " (seq_author.NEXTVAL,?, ?, ?)";

		private static final String SELECT_USER_BY_ID = "select author_id,first_name,last_name, email_address from author1 where author_id =?";
		private static final String SELECT_ALL_USERS = "select * from author1";
		private static final String DELETE_USERS_SQL = "delete from author1 where author_id = ?";
		private static final String UPDATE_USERS_SQL = "update author1 set first_name = ?,"
				+ "last_name= ?," + "email_address= ?  where author_id = ?";

		public AuthorDao() {
		}

		protected Connection getConnection() {
			Connection connection = null;
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
						jdbcPassword);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return connection;
		}

		public void insertUser(Author author) throws SQLException {
			System.out.println(INSERT_USERS_SQL);
			// try-with-resource statement will auto close the connection.
			try {Connection connection = getConnection();
					PreparedStatement preparedStatement = connection.prepareStatement
														(INSERT_USERS_SQL);
				preparedStatement.setString(1, author.getFirst_name());
				preparedStatement.setString(2, author.getLast_name());
				preparedStatement.setString(3, author.getEmail_address());
				
				System.out.println(preparedStatement);
				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				printSQLException(e);
			}
		}

		public Author selectUser(int author_id) {
			Author author = null;
			// Step 1: Establishing a Connection
			try {Connection connection = getConnection();
					// Step 2:Create a statement using connection object
					PreparedStatement preparedStatement = connection.prepareStatement
														(SELECT_USER_BY_ID);
				preparedStatement.setInt(1, author_id);
				System.out.println(preparedStatement);
				// Step 3: Execute the query or update query
				ResultSet rs = preparedStatement.executeQuery();

				// Step 4: Process the ResultSet object.
				while (rs.next()) {
					String first_name = rs.getString("first_name");
					String last_name = rs.getString("last_name");
					String email_address = rs.getString("email_address");
					
					
					author = new Author(author_id, first_name, last_name, email_address);
				}
			} catch (SQLException e) {
				printSQLException(e);
			}
			return author;
		}

		public List<Author> selectAllUsers() {

			// using try-with-resources to avoid closing resources (boiler plate code)
			List<Author> authorlist = new ArrayList<>();
			// Step 1: Establishing a Connection
			try {Connection connection = getConnection();

					// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
						(SELECT_ALL_USERS);
				System.out.println(preparedStatement);
				// Step 3: Execute the query or update query
				ResultSet rs = preparedStatement.executeQuery();

				// Step 4: Process the ResultSet object.
				while (rs.next()) {
					
					int author_id = rs.getInt("author_id");
					String first_name = rs.getString("first_name");
					String last_name = rs.getString("last_name");
					String email_address = rs.getString("email_address");
				
					authorlist.add(new Author(author_id, first_name, last_name, email_address));
				}
			} catch (SQLException e) {
				printSQLException(e);
			}
			return authorlist;
		}

		public boolean deleteUser(int author_id) throws SQLException {
			boolean rowDeleted;
			try (Connection connection = getConnection();
					PreparedStatement statement = connection.prepareStatement
													(DELETE_USERS_SQL);) {
				statement.setInt(1, author_id);
				rowDeleted = statement.executeUpdate() > 0;
			}
			return rowDeleted;
		}

		public boolean updateUser(Author auth) throws SQLException {
			boolean rowUpdated;
			try (Connection connection = getConnection();
					PreparedStatement statement = connection.prepareStatement
							(UPDATE_USERS_SQL);) {
				statement.setString(1, auth.getFirst_name());
				statement.setString(2,auth.getLast_name());
				statement.setString(3, auth.getEmail_address());
				statement.setInt(4, auth.getAuthor_id());

				rowUpdated = statement.executeUpdate() > 0;
			}
			return rowUpdated;
		}

		private void printSQLException(SQLException ex) {
			
					ex.printStackTrace();
					
					}
				
	}


