package com.lti.DAO;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.books.Books;

public class BookInstanceDao {
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "123";

	private static final String INSERT_BOOKINSTANCE_SQL = "INSERT INTO bookinstance VALUES "
			+ " (seq_books.NEXTVAL,?, ?, ?)";

	private static final String SELECT_BOOKINSTANCE_ID = "select isbn,copy_instance,order_details_id, store_id from bookinstance where copy_instance =?";
	private static final String SELECT_ALL_BOOKINSTANCE = "select * from bookinstance";
	private static final String DELETE_BOOKINSTANCE_SQL = "delete from bookinstance where copy_instance = ?";
	private static final String UPDATE_BOOKINSTANCE_SQL = "update bookinstance set order_details_id = ?,"
			+ "store_id= ?," + "isbn= ?  where copy_instance = ?";

	public BookInstanceDao() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

  public void insertBookInstance(BookInstance bk) throws SQLException {
    System.out.println(INSERT_BOOKINSTANCE_SQL);
    try {
      Connection connection = getConnection();
      PreparedStatement preparedStatement = connection.preparedStatement(INSERT_BOOKINSTANCE_SQL);
      preparedStatement.setInt(1, bk.getStoreId());
      preparedStatement.setInt(2, bk.getIsbn());
      preparedStatement.setInt(3, bk.getOrderDetailsId());
      System.out.println(preparedStatement);
      preparedStatement.executeUpdate();
    } catch(SQLException e) {
      printSQLException(e);
    }
  }

  public Books selectBookInstance(int copy_instance) {
		BookInstance bk = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_BOOKINSTANCE_ID);
			preparedStatement.setInt(1, isbn);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String title = rs.getString("title");
				int author_id = rs.getInt("author_id");
				int publisher_id = rs.getInt("publisher_id");

        int store_id = rs.getInt("store_id");
        int isbn = rs.getInt("isbn");
        int order_details_id = rs.getInt("order_details_id");

        bk = new BookInstance(copy_instance, store_id, isbn, order_details_id);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return bk;
	}

	public List<BookInstance> selectAllBookInstance() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<BookInstance> bookinstancelist = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_BOOKINSTANCE);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int isbn = rs.getInt("isbn");
				int copy_instance = rs.getInt("copy_instance");
        int store_id = rs.getInt("store_id");
        int order_details_id = rs.getInt("order_details_id");
			
				bookinstancelist.add(new Books(copy_instance, store_id, isbn, order_details_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return bookinstancelist;
	}

	public boolean deleteBookInstance(int copy_instance) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_BOOKINSTANCE_SQL);) {
			statement.setInt(1, copy_instance);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateBookInstance(BookInstance bk) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_BOOKINSTANCE_SQL);) {
			statement.setInt(1, bk.getOrderDetailsId());
			statement.setInt(2, bk.getStoreId());
			statement.setInt(3, bk.getIsbn());
			statement.setInt(4, bk.getCopyInstance());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException e) {
	  e.printStackTrace();
	}		
}
