package com.lti.DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.books.Books;

public class BookDao {
	
		private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
		private String jdbcUsername = "system";
		private String jdbcPassword = "tiger";

		private static final String INSERT_USERS_SQL = "INSERT INTO books11 VALUES "
				+ " (seq_user.NEXTVAL,?, ?, ?)";

		private static final String SELECT_USER_BY_ID = "select isbn,book_title,a_id,p_id,"
				+ " from books11 where isbn =?";
		private static final String SELECT_ALL_USERS = "select * from books11";
		private static final String DELETE_USERS_SQL = "delete from books11 where isbn = ?";
		private static final String UPDATE_USERS_SQL = "update books11 set book_title = ?,"
				+ " where isbn = ?";

	
		protected Connection getConnection() {
			Connection connection = null;
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
						jdbcPassword);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return connection;
		}

		public void insertUser(Books user) throws SQLException {
			System.out.println(INSERT_USERS_SQL);
			// try-with-resource statement will auto close the connection.
			try {Connection connection = getConnection();
					PreparedStatement preparedStatement = connection.prepareStatement
														(INSERT_USERS_SQL);
				
				preparedStatement.setString(1, user.getBook_title());
				preparedStatement.setInt(2, user.getAuthor_id());
				preparedStatement.setInt(3, user.getPublisher_id());
				System.out.println(preparedStatement);
				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				printSQLException(e);
			}
		}

		public Books selectUser(int isbn) {
			Books user = null;
			// Step 1: Establishing a Connection
			try {Connection connection = getConnection();
					// Step 2:Create a statement using connection object
					PreparedStatement preparedStatement = connection.prepareStatement
														(SELECT_USER_BY_ID);
				preparedStatement.setInt(1, isbn);
				System.out.println(preparedStatement);
				// Step 3: Execute the query or update query
				ResultSet rs = preparedStatement.executeQuery();

				// Step 4: Process the ResultSet object.
				while (rs.next()) {
					
					String book_title = rs.getString("book_title");
					int a_id = rs.getInt("a_id");
					int p_id=rs.getInt("p_id");
					user = new Books(isbn, book_title, a_id, p_id);
				}
			} catch (SQLException e) {
				printSQLException(e);
			}
			return user;
		}

		public List<Books> selectAllUsers() {

			// using try-with-resources to avoid closing resources (boiler plate code)
			List<Books> users = new ArrayList<>();
			// Step 1: Establishing a Connection
			try {Connection connection = getConnection();

					// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
						(SELECT_ALL_USERS);
				System.out.println(preparedStatement);
				// Step 3: Execute the query or update query
				ResultSet rs = preparedStatement.executeQuery();

				// Step 4: Process the ResultSet object.
				while (rs.next()) {
					int isbn = rs.getInt("isbn");
					String book_title = rs.getString("book_title");
					int a_id = rs.getInt("a_id");
					int p_id=rs.getInt("p_id");
					users.add(new Books(isbn, book_title, a_id, p_id));
			
					
				}
			} catch (SQLException e) {
				printSQLException(e);
			}
			return users;
		}

		public boolean deleteUser(int isbn) throws SQLException {
			boolean rowDeleted;
			try (Connection connection = getConnection();
					PreparedStatement statement = connection.prepareStatement
													(DELETE_USERS_SQL);) {
				statement.setInt(1, isbn);
				rowDeleted = statement.executeUpdate() > 0;
			}
			return rowDeleted;
		}

		public boolean updateUser(Books user) throws SQLException {
			boolean rowUpdated;
			try (Connection connection = getConnection();
					PreparedStatement statement = connection.prepareStatement
							(UPDATE_USERS_SQL);) {
				
				statement.setString(1, user.getBook_title());
				statement.setInt(2, user.getAuthor_id());
				statement.setInt(3, user.getPublisher_id());
				rowUpdated = statement.executeUpdate() > 0;
			}
			return rowUpdated;
		}

		private void printSQLException(SQLException ex) {
			
					ex.printStackTrace();
					
					}
				
	

}
