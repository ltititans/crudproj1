package com.lti.college.implementedClasses;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.lti.CollegeDetails.beanClass.DepartmentBean;
import com.lti.JDBC.JDBC_Connect;
import com.lti.college_interfaces.DeptInterface;





public class DeptImpl implements DeptInterface {

	DepartmentBean d =new DepartmentBean(0, null, null);
	
	
	public void Department() throws SQLException, NumberFormatException, IOException
	{
		
	DeptImpl d1 =new DeptImpl();
	
	while(true)
		
	{
	System.out.println("Entities ");
	System.out.println("1.Add department");
	System.out.println("2. Display departemnt");
	System.out.println("3. Update department");
	System.out.println("4. Delete department");
	Scanner in= new Scanner(System.in);
	
	int c;
		c=in.nextInt();

	switch(c)
		{
		case 1: 
	d1.addDept();
		break ;
		case 2:			
	d1.displayDept();
		
		break ;
		case 3:
			d1.updateDept();
			break;
		case 4:
			d1.deleteDept();
			break;
	
		default :System.exit(0);
		break;
		}  
		}
	}


	
	
//	List<DepartmentBean> li=new ArrayList<DepartmentBean>();
	
	Statement st=null;
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	
//	public void create() throws SQLException
//	{
	
//	try
//	{
//		con=JDBC_Connect.getConnect();
//		st=con.createStatement();
//	
//	String str="create table Department(dnumber number(10) PRIMARY KEY,dname varchar2(50),location varchar(20))";
//	st.execute(str);
//	System.out.println("Table Created");
//	}
//	catch(Exception e){
//		e.printStackTrace();
//		System.out.println("Table already created");
//	}
////	List<Integer,String,String> li= new ArrayList<Integer,String,String>();
//	
//	
//}
	public void addDept() throws SQLException {

		try{
	
		con=JDBC_Connect.getConnect();
		ps=con.prepareStatement("insert into Department values(?,?,?)");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		do
		{
			System.out.println("Enter the Department id:");
			d.setDnumber(Integer.parseInt(br.readLine()));
			
			System.out.println("Enter the Department name:");
			d.setDname(br.readLine());

			System.out.println("Enter the Department location:");
			d.setLocation(br.readLine());
			
			ps.setInt(1, d.getDnumber());
			
			ps.setString(2, d.getDname());
			
			ps.setString(3, d.getLocation());
			
			
			int rows=ps.executeUpdate();
			System.out.println(rows+" recoreds affected");
			
		System.out.println("Do you want to continue : y/n");
		String s=br.readLine();
		if(s.startsWith("n"))
		{
			break;
		}
		}
		while(true);
		
		con.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void displayDept() 
	{
		d.getDnumber();
		d.getDname();
		d.getLocation();
		System.out.println(d.getDnumber() + " " + d.getDname() + " " + 	d.getLocation());
		 
	}

	@Override
	public void deleteDept() throws SQLException, NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		con=JDBC_Connect.getConnect();
		st=con.createStatement();
		ps=con.prepareStatement("Delete from department where dnumber=?");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		    System.out.println("Enter the product1 id:");
		    int dnumber=Integer.parseInt(br.readLine());
			
			
			ps.setInt(1, dnumber);
			
		    int rows=ps.executeUpdate();
			System.out.println(rows+" records deleted ");
			
		
	}

	@Override
	public void updateDept() throws SQLException, NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		con=JDBC_Connect.getConnect();
		st=con.createStatement();
		ps=con.prepareStatement("Update department set dname= ? where dnumber=?");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		    System.out.println("Enter the Dnumber:");
		    int dnumber=Integer.parseInt(br.readLine());
			System.out.println("Enter the new Department name:");
			String dname=br.readLine();
			
			ps.setString(1, dname);
			ps.setInt(2, dnumber);
			
		    int rows=ps.executeUpdate();
			System.out.println(rows+" recoreds affected");
		
		
	}

}
