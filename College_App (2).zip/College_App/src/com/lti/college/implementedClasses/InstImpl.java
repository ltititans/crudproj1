package com.lti.college.implementedClasses;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.lti.CollegeDetails.beanClass.DepartmentBean;
import com.lti.CollegeDetails.beanClass.InstructorBean;
import com.lti.JDBC.JDBC_Connect;
import com.lti.college_interfaces.InstInterface;

public class InstImpl implements InstInterface{

	Statement st=null;
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	InstructorBean ib=new InstructorBean(0, null, null, null);
	DepartmentBean db=new DepartmentBean(0, null, null);

	public void Instructor() throws SQLException, NumberFormatException, IOException
	{

		InstImpl i1 =new InstImpl();

		while(true)

		{
			System.out.println("Attributes ");
			System.out.println("1.Add department");
			System.out.println("2. Display departemnt");
			System.out.println("3. Update department");
			System.out.println("4. Delete department");
			Scanner in= new Scanner(System.in);

			int c;
			c=in.nextInt();

			switch(c)
			{
			case 1: 
				i1.addInstructor();;
				break ;
			case 2:			
				i1.displayInstructor();

				break ;
			case 3:
				i1.updateInstructor();
				break;
			case 4:
				i1.deleteInstructor();
				break;

			default :System.exit(0);
			break;
			}  
		}
	}

	@Override
	public void addInstructor() {
		// TODO Auto-generated method stub
		try{

			con=JDBC_Connect.getConnect();
			ps=con.prepareStatement("insert into Instructor values(?,?,?,?)");
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

			do
			{
				System.out.println("Enter the Instructor id:");
				ib.setIid(Integer.parseInt(br.readLine()));

				System.out.println("Enter the Instructor name:");
				ib.setIname(br.readLine());

				System.out.println("Enter the Instructor room:");
				ib.setRoom(br.readLine());
				System.out.println("Enter the department id:");
				db.setDnumber(Integer.parseInt(br.readLine()));

				ps.setInt(1, ib.getIid());

				ps.setString(2, ib.getIname());

				
				ps.setString(3, ib.getRoom());
				ps.setInt(4, db.getDnumber());

				int rows=ps.executeUpdate();
				System.out.println(rows+" recoreds affected");

				System.out.println("Do you want to continue : y/n");
				String s=br.readLine();
				if(s.startsWith("n"))
				{
					break;
				}
			}
			while(true);

			con.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void displayInstructor() {
		// TODO Auto-generated method stub
		ib.getIid();
		ib.getIname();
		ib.getRoom();
		db.getDnumber();
		System.out.println(ib.getIid() + " " +ib.getIname() + " " + 	ib.getRoom()+ " "+db.getDnumber());
	}

	@Override
	public void deleteInstructor() throws SQLException, NumberFormatException, IOException {
		// TODO Auto-generated method stub
		con=JDBC_Connect.getConnect();
		st=con.createStatement();
		ps=con.prepareStatement("Delete from Instructor where iid=?");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter the Instructor id:");
		int iid=Integer.parseInt(br.readLine());


		ps.setInt(1, iid);

		int rows=ps.executeUpdate();
		System.out.println(rows+" records deleted ");
	}

	@Override
	public void updateInstructor() throws SQLException, NumberFormatException, IOException {
		// TODO Auto-generated method stub
		con=JDBC_Connect.getConnect();
		st=con.createStatement();
		ps=con.prepareStatement("Update instructor set iname= ? where iid=?");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter the  Instructor number:");
		int iid=Integer.parseInt(br.readLine());
		System.out.println("Enter the new Instructor name:");
		String iname=br.readLine();

		ps.setString(1, iname);
		ps.setInt(2, iid);

		int rows=ps.executeUpdate();
		System.out.println(rows+" recoreds affected");
	}

}
