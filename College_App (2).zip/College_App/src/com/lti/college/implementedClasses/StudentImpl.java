package com.lti.college.implementedClasses;

import com.lti.college_interfaces.StudentInterface;

public class StudentImpl implements StudentInterface{

	@Override
	public void addStud() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayStud() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteStud() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateStud() {
		// TODO Auto-generated method stub
		
	}

}
