package com.lti.college.implementedClasses;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.lti.CollegeDetails.beanClass.CourseBean;
import com.lti.CollegeDetails.beanClass.InstructorBean;
import com.lti.JDBC.JDBC_Connect;
import com.lti.college_interfaces.CourseInterface;

public class CouseImpl implements CourseInterface{

	Statement st=null;
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	CourseBean cb=new CourseBean(0, null,null, null, null);
	InstructorBean ib=new InstructorBean(0, null, null, null);
	public void Course() throws NumberFormatException, SQLException, IOException
	{
		CouseImpl c1=new CouseImpl();
	
	while(true)

	{
		System.out.println("Attributes ");
		System.out.println("1.Add Course");
		System.out.println("2. Display Course");
		System.out.println("3. Update Course");
		System.out.println("4. Delete Course");
		Scanner in= new Scanner(System.in);
        int c;
		c=in.nextInt();
		switch(c)
		{
		case 1: 
			c1.addCourse();
			break ;
		case 2:			
			c1.displayCourse();

			break ;
		case 3:
	          c1.updateCourse();
			break;
		case 4:
			c1.deleteCourse();
			break;

		default :System.exit(0);
		break;
		}  
	}
	}
	
	
	@Override
	public void addCourse() {
		// TODO Auto-generated method stub
		try{

			con=JDBC_Connect.getConnect();
			ps=con.prepareStatement("insert into Course values(?,?,?,?,?)");
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

			do
			{
				System.out.println("Enter the Course no:");
				cb.setCourseno(Integer.parseInt(br.readLine()));

				System.out.println("Enter the course name:");
				cb.setCname(br.readLine());

				System.out.println("Enter the Duration:");
				cb.setDuration(br.readLine());
				System.out.println("Enter the pre requisite:");
				cb.setPrerequisite(br.readLine());
				System.out.println("Enter the Instructor id :");
				ib.setIid(Integer.parseInt(br.readLine()));

				ps.setInt(1, cb.getCourseno());

				ps.setString(2, cb.getCname());

				
				ps.setString(3, cb.getDuration());
				ps.setString(4, cb.getPrerequisite());
				ps.setInt(5, ib.getIid());
				
				

				int rows=ps.executeUpdate();
				System.out.println(rows+" recoreds affected");

				System.out.println("Do you want to continue : y/n");
				String s=br.readLine();
				if(s.startsWith("n"))
				{
					break;
				}
			}
			while(true);

			con.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void displayCourse() {
		// TODO Auto-generated method stub
		cb.getCourseno();
		cb.getCname();
		cb.getDuration();
		cb.getPrerequisite();
		ib.getIname();
		
		System.out.println(cb.getCourseno() + " " +cb.getCname() + " " + 	cb.getDuration()+ " "+cb.getPrerequisite() + " " +ib.getIid());
	}

	@Override
	public void deleteCourse() throws SQLException, NumberFormatException, IOException {
		// TODO Auto-generated method stub
		con=JDBC_Connect.getConnect();
		st=con.createStatement();
		ps=con.prepareStatement("Delete from Course where courseno=?");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter the Course number:");
		int courseno=Integer.parseInt(br.readLine());


		ps.setInt(1, courseno);

		int rows=ps.executeUpdate();
		System.out.println(rows+" records deleted ");
	}
	

	@Override
	public void updateCourse() throws SQLException, NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		con=JDBC_Connect.getConnect();
		st=con.createStatement();
		ps=con.prepareStatement("Update Course set cname= ? where courseno=?");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter the  Course number:");
		int courseno=Integer.parseInt(br.readLine());
		System.out.println("Enter the new Course name:");
		String cname=br.readLine();

		ps.setString(1, cname);
		ps.setInt(2, courseno);

		int rows=ps.executeUpdate();
		System.out.println(rows+" recoreds affected");
		
		
	}

	

}
