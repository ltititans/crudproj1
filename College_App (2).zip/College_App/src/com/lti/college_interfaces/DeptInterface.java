package com.lti.college_interfaces;

import java.io.IOException;
import java.sql.SQLException;

public interface DeptInterface {

	void addDept() throws SQLException;
	void displayDept();
	void deleteDept() throws SQLException, NumberFormatException, IOException;
	void updateDept() throws SQLException, NumberFormatException, IOException;
	
}
