package com.lti.college_interfaces;

import java.io.IOException;
import java.sql.SQLException;

public interface InstInterface {
	
	void addInstructor();
	void displayInstructor();
	void deleteInstructor() throws SQLException, NumberFormatException, IOException;
	void updateInstructor() throws SQLException, NumberFormatException, IOException;
	

}
