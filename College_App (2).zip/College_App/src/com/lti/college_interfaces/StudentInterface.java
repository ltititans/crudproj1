package com.lti.college_interfaces;

public interface StudentInterface 
{
	
	void addStud();
	void displayStud();
	void deleteStud();
	void updateStud();
	

}
