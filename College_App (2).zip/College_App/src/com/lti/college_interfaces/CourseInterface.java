package com.lti.college_interfaces;

import java.io.IOException;
import java.sql.SQLException;

public interface CourseInterface 
{
	
	void addCourse();
	void displayCourse();
	void deleteCourse() throws SQLException, NumberFormatException, IOException;
	void updateCourse() throws SQLException, NumberFormatException, IOException;
	

}
