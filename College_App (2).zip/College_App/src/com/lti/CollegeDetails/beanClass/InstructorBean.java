package com.lti.CollegeDetails.beanClass;

public class InstructorBean {

	private int iid;
	private String iname;
	private String room;
	private DepartmentBean db;
	public InstructorBean(int iid, String iname, String room, DepartmentBean db) {
		this.iid = iid;
		this.iname = iname;
		this.room = room;
		this.db = db;
	}
	public int getIid() {
		return iid;
	}
	public void setIid(int iid) {
		this.iid = iid;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public DepartmentBean getDb() {
		return db;
	}
	public void setDb(DepartmentBean db) {
		this.db = db;
	}
	@Override
	public String toString() {
		return "InstructorBean [iid=" + iid + ", iname=" + iname + ", room=" + room + ", db=" + db + "]";
	}
	
}