package com.lti.CollegeDetails.beanClass;

public class CourseBean {
	
	private int courseno;
	private String cname;
	private String duration;
	private String prerequisite;
	private InstructorBean ib;
	public CourseBean(int courseno, String cname, String duration, String prerequisite, InstructorBean ib) {
		this.courseno = courseno;
		this.cname = cname;
		this.duration = duration;
		this.prerequisite = prerequisite;
		this.ib = ib;
	}
	public int getCourseno() {
		return courseno;
	}
	public void setCourseno(int courseno) {
		this.courseno = courseno;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getPrerequisite() {
		return prerequisite;
	}
	public void setPrerequisite(String prerequisite) {
		this.prerequisite = prerequisite;
	}
	public InstructorBean getIb1() {
		return ib;
	}
	public void setIb1(InstructorBean ib) {
		this.ib = ib;
	}
	@Override
	public String toString() {
		return "CourseBean [courseno=" + courseno + ", cname=" + cname + ", duration=" + duration + ", prerequisite="
				+ prerequisite + ", ib=" + ib + "]";
	}
	

}
