package com.lti.CollegeDetails.beanClass;

public class StudentBean {
	
	private int sno;
	private String sname;
	private String dob;
	
	private CourseBean cb;
	private InstructorBean ib;
	public StudentBean(int sno, String sname, String dob, CourseBean cb, InstructorBean ib) {
		this.sno = sno;
		this.sname = sname;
		this.dob = dob;
		this.cb = cb;
		this.ib = ib;
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public CourseBean getCb() {
		return cb;
	}
	public void setCb(CourseBean cb) {
		this.cb = cb;
	}
	public InstructorBean getIb2() {
		return ib;
	}
	public void setIb2(InstructorBean ib) {
		this.ib = ib;
	}
	@Override
	public String toString() {
		return "StudentBean [sno=" + sno + ", sname=" + sname + ", dob=" + dob + ", cb=" + cb + ", ib=" + ib + "]";
	}
	

}
