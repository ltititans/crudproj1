package com.lti.CollegeDetails.MainClass;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;


import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.lti.CollegeDetails.beanClass.CourseBean;
import com.lti.CollegeDetails.beanClass.DepartmentBean;
import com.lti.CollegeDetails.beanClass.InstructorBean;
import com.lti.CollegeDetails.beanClass.StudentBean;
import com.lti.college.implementedClasses.DeptImpl;
import com.lti.college.implementedClasses.InstImpl;

public class CollegeMain {

public static void main(String[] args) throws SQLException, NumberFormatException, IOException {
			
			DeptImpl d1 =new DeptImpl();
			InstImpl i1=new InstImpl();
//			d.addDept();
//			d.addDept();
//			d.displayDept();
//			d.create();
		while(true)
				
		{
		System.out.println("Entities ");
		System.out.println("1.Department");
		System.out.println("2.Instructor");
		Scanner in= new Scanner(System.in);
		
		int c;
			c=in.nextInt();
	
		switch(c)
			{
			case 1: 
		d1.Department();
			break ;
			case 2:			
		i1.Instructor();
			
			break ;
			default :System.exit(0);
			break;
			}  
			}
		}
		}
		

